/* File : main.c */
/* Deskripsi : aplikasi driver ADT list berkait doubly linear, representasi fisik pointer */
/* NIM & Nama : 24060124140166/Muhammad Farhan Abdul Azis */
/* Tanggal : 20 November 2025 */
#include <stdio.h>
#include <stdlib.h>
#include "boolean.h"
#include "list3.h"

int main() {
    // Kamus
    List3 L;
    infotype val;
    int jumlah;
    address found;
    address A;
    address B;
    address P;
    List3 Senarai;

    // Algoritma
    printf("=== TEST MANUAL ALOKASI ===\n");
    A = (address) malloc ( sizeof (Elm) ); // Alokasi('G')
    A->info = 'G';   A->next = NIL; A->prev = NIL;
    printf("info(A)=%c\t", info(A) );
    B = (address) malloc ( sizeof (Elm) ); // Alokasi('N')
    B->info = 'N';   B->next = A; B->prev = NIL;
    prev(A) = B;
    printf("info(B)=%c\n", info(B) );
    
    Senarai.First = B;
    printf("Isi Senarai :");
    P = First(Senarai);
    while (P != NIL) {
      printf("\t%c",info(P));
      P = next(P);
    }
    printf("\n");
    free(B);
    free(A);

    // 1. Test CreateList
    printf("\n=== TEST CreateList ===\n");
    CreateList(&L);
    printf("List L berhasil dibuat.\n");

    // 2. Test IsEmptyList
    printf("\n=== TEST IsEmptyList ===\n");
    if (IsEmptyList(L)) {
        printf("List L kosong.\n");
    } else {
        printf("List L tidak kosong.\n");
    }

    // 3. Test InsertVFirst
    printf("\n=== TEST InsertVFirst ===\n");
    InsertVFirst(&L, 'A');
    printf("Insert 'A' di awal.");
    PrintList(L);
    InsertVFirst(&L, 'B');
    printf("\nInsert 'B' di awal.");
    PrintList(L);
    InsertVFirst(&L, 'C');
    printf("\nInsert 'C' di awal.");
    PrintList(L);

    // 4. Test InsertVLast
    printf("\n\n=== TEST InsertVLast ===\n");
    InsertVLast(&L, 'X');
    printf("Insert 'X' di akhir.");
    PrintList(L);
    InsertVLast(&L, 'Y');
    printf("\nInsert 'Y' di akhir.");
    PrintList(L);
    InsertVLast(&L, 'Z');
    printf("\nInsert 'Z' di akhir.");
    PrintList(L);

    // 5. Test PrintList dan NbElm
    printf("\n\n=== TEST PrintList & NbElm ===\n");
    printf("Isi list L:");
    PrintList(L);
    jumlah = NbElm(L);
    printf("\nJumlah elemen: %d\n", jumlah);

    // 6. Test IsEmptyList (setelah diisi)
    printf("\n=== TEST IsEmptyList (setelah diisi) ===\n");
    if (IsEmptyList(L)) {
        printf("List L kosong.\n");
    } else {
        printf("List L tidak kosong.\n");
    }

    // 7. Test SearchX
    printf("\n=== TEST SearchX ===\n");
    SearchX(L, 'A', &found);
    if (found != NIL) {
        printf("Elemen 'A' ditemukan, info=%c\n", info(found));
    } else {
        printf("Elemen 'A' tidak ditemukan.\n");
    }
    SearchX(L, 'Q', &found);
    if (found != NIL) {
        printf("Elemen 'Q' ditemukan, info=%c\n", info(found));
    } else {
        printf("Elemen 'Q' tidak ditemukan.\n");
    }

    // 8. Test UpdateX
    printf("\n=== TEST UpdateX ===\n");
    printf("Sebelum UpdateX('A' -> 'M'):");
    PrintList(L);
    UpdateX(&L, 'A', 'M');
    printf("\nSetelah UpdateX('A' -> 'M'):");
    PrintList(L);

    // 9. Test DeleteVFirst
    printf("\n\n=== TEST DeleteVFirst ===\n");
    printf("Sebelum DeleteVFirst:");
    PrintList(L);
    DeleteVFirst(&L, &val);
    printf("\nElemen yang dihapus: %c", val);
    printf("\nSetelah DeleteVFirst:");
    PrintList(L);
    printf("\nJumlah elemen: %d\n", NbElm(L));

    // 10. Test DeleteVLast
    printf("\n=== TEST DeleteVLast ===\n");
    printf("Sebelum DeleteVLast:");
    PrintList(L);
    DeleteVLast(&L, &val);
    printf("\nElemen yang dihapus: %c", val);
    printf("\nSetelah DeleteVLast:");
    PrintList(L);
    printf("\nJumlah elemen: %d\n", NbElm(L));

    // 11. Test DeleteX
    printf("\n=== TEST DeleteX ===\n");
    printf("Sebelum DeleteX('M'):");
    PrintList(L);
    DeleteX(&L, 'M');
    printf("\nSetelah DeleteX('M'):");
    PrintList(L);
    printf("\nJumlah elemen: %d\n", NbElm(L));

    // 12. Test Invers
    printf("\n=== TEST Invers ===\n");
    // Tambah elemen untuk test invers
    InsertVLast(&L, 'P');
    InsertVLast(&L, 'Q');
    InsertVLast(&L, 'R');
    printf("Sebelum Invers:");
    PrintList(L);
    Invers(&L);
    printf("\nSetelah Invers:");
    PrintList(L);
    printf("\nJumlah elemen: %d\n", NbElm(L));

    return 0;
}