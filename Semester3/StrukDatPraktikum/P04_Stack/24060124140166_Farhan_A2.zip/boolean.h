#ifndef boolean_H
#define boolean_H
/*/
/* Program   : boolean.h */
/* Deskripsi : header file modul boolean */
/* NIM/Nama  : 24060124140166/Muhammad Farhan Abdul Azis*/
/* Tanggal   : 25 September 2025*/

//type boolean macro bahasa C, false=0, true=1
#define false 0
#define true  1
#define boolean unsigned char

#endif